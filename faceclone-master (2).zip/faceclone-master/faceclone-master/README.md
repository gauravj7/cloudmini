## FaceClone Project
This repo contains the full project for my Medium series on building a Facebook clone with PHP from scratch.

### Part 1
* Install the necessary apps (Sublime Text 3, XAMPP and Filezilla)
* Explore the HTML template
* Serve the template with PHP's development server

### Part 2
* Create and use partials
* Write a schema
* Create the database

### Part 3
* Connect to DB
* Create, read and delete posts

### Part 4
* User registration
* Login
* Logout

### Part 5
* Display user profile
* Edit/update profile

### Part 6
* List users
* Send friend request
* Accept/decline friend request
* Unfriend user